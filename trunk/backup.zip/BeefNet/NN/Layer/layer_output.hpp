#ifndef LAYER_OUTPUT_HPP_
#define LAYER_OUTPUT_HPP_

#include "../Weight/weight_vector.hpp"
#include "../Neuron/neuron.hpp"
#include "../Neuron/neuron_target.hpp"

namespace wwd
{

template < uint32 PatternNum,
           uint32 InputNum,
           uint32 OutputNum,
           class Xfer,
           template < uint32, class > class WeightType,
           class Param >
class CLayerOutput
{
private:

    typedef CWeightVector< PatternNum,
                           InputNum,
                           WeightType,
                           Param > WeightVector;

public:

    template < class Other >
    const CLayerOutput &operator>>( OUT Other &other ) const
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i] >> other.get_weight_vector(i);
        }

        return *this;
    }

    template < class Other >
    CLayerOutput &operator<<( IN Other &other )
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i] << other.get_weight_vector(i);
        }

        return *this;
    }

    CLayerOutput(void)
    {
        connect_inner();
    }

    ~CLayerOutput(void)
    {
    }

    void forward(void)
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i].forward();
            m_output[i].forward();
        }
    }

    void backward(void)
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_target[i].backward();
            m_output[i].backward();
            m_weight_vector[i].backward();
        }
    }

    void update(void)
    {
        for ( auto &i : m_weight_vector )
        {
            i.update();
        }
    }

    template < class Layer >
    void connect_input_layer( INOUT Layer &layer )
    {
        for ( uint32 i = 0; i < Layer::hidden_num; ++i )
        {
            for ( auto &j : m_weight_vector )
            {
                j.connect_input_neuron( layer.get_hidden_node(i) );
            }
        }
    }

    void set_target( IN const double (&target)[OutputNum] )
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_target[i].set_target( target[i] );
        }
    }

    inline WeightVector &get_weight_vector( IN uint32 idx )
    {
        return m_weight_vector[idx];
    }

#ifdef _DEBUG
    void print_weight(void) const
    {
        for ( const auto &i : m_weight_vector )
        {
            i.print_weight();
        }

        std::cout << std::endl;
    }
#endif // _DEBUG

private:

    void connect_inner(void)
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i].connect_output_neuron( m_output[i] );
            m_target[i].connect_input_neuron( m_output[i] );
        }
    }

private:

    WeightVector m_weight_vector[OutputNum];
    CNeuron< InputNum, 1, Xfer > m_output[OutputNum];
    CNeuronTarget m_target[OutputNum];
};

template < uint32 PatternNum,
           uint32 InputNum,
           uint32 OutputNum,
           class Xfer,
           class Param >
class CLayerOutput< PatternNum,
                    InputNum,
                    OutputNum,
                    Xfer,
                    CWeightLM,
                    Param >
{
private:

    typedef CWeightVector< PatternNum,
                           InputNum,
                           CWeightLM,
                           Param > WeightVector;

public:

    CLayerOutput(void)
    {
        connect_inner();
    }

    ~CLayerOutput(void)
    {
    }

    template < class Other >
    const CLayerOutput &operator>>( OUT Other &other ) const
    {
        return *this;
    }

    template < class Other >
    CLayerOutput &operator<<( IN Other &other )
    {
        return *this;
    }

    void forward(void)
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i].forward();
            m_output[i].forward();
        }
    }

    void backward( IN uint32 pattern_idx, IN uint32 output_idx )
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_target[i].set_output_value( ( i == output_idx ) ? 1.0 : 0.0 );
            m_output[i].backward();
            m_weight_vector[i].backward( pattern_idx, output_idx );
        }
    }

    void update( IN const double (&err)[ PatternNum * Param::output_num ] )
    {
        for ( auto &i : m_weight_vector )
        {
            i.update(err);
        }
    }

    void revert(void)
    {
        for ( auto &i : m_weight_vector )
        {
            i.revert();
        }
    }

    template < class Layer >
    void connect_input_layer( INOUT Layer &layer )
    {
        for ( uint32 i = 0; i < Layer::hidden_num; ++i )
        {
            for ( auto &j : m_weight_vector )
            {
                j.connect_input_neuron( layer.get_hidden_node(i) );
            }
        }
    }

    void set_target( IN const double *target )
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_target[i].set_target( target[i] );
        }
    }

    double get_error( IN uint32 idx )
    {
        m_target[idx].backward();

        return m_target[idx].get_output_value();
    }

    inline WeightVector &get_weight_vector( IN uint32 idx )
    {
        return m_weight_vector[idx];
    }

#ifdef _DEBUG
    void print_weight(void) const
    {
        for ( const auto &i : m_weight_vector )
        {
            i.print_weight();
        }

        std::cout << std::endl;
    }
#endif // _DEBUG

private:

    void connect_inner(void)
    {
        for ( uint32 i = 0; i < OutputNum; ++i )
        {
            m_weight_vector[i].connect_output_neuron( m_output[i] );
            m_target[i].connect_input_neuron( m_output[i] );
        }
    }

private:

    WeightVector m_weight_vector[OutputNum];
    CNeuron< InputNum, 1, Xfer > m_output[OutputNum];
    CNeuronTarget m_target[OutputNum];
};

} // namespace wwd

#endif // LAYER_OUTPUT_HPP_

