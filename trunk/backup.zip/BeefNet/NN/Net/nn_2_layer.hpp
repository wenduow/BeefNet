#ifndef NN_2_LAYER_HPP
#define NN_2_LAYER_HPP

#include "../Layer/layer_input.hpp"
#include "../Layer/layer.hpp"
#include "../Layer/layer_output.hpp"

namespace wwd
{

template < uint32 PatternNum,
           uint32 InputNum,
           uint32 HiddenNum0, class Xfer0,
           uint32 HiddenNum1, class Xfer1,
           uint32 OutputNum, class XferOutput,
           template < uint32, class > class WeightType, class Param >
class CNN2Layer
{
private:

    typedef CLayer< PatternNum, InputNum + 1, HiddenNum0, HiddenNum1, Xfer0,
                    WeightType, Param > Layer0;
    typedef CLayer< PatternNum, HiddenNum0 + 1, HiddenNum1, OutputNum, Xfer1,
                    WeightType, Param > Layer1;
    typedef CLayerOutput< PatternNum, HiddenNum1 + 1, OutputNum, XferOutput,
                          WeightType, Param > LayerOutput;

public:

    CNN2Layer(void)
    {
        connect_inner();
    }

    ~CNN2Layer(void)
    {
    }

    template < class Other >
    const CNN2Layer &operator>>( OUT Other &other ) const
    {
        m_layer_0 >> other.get_layer_0();
        m_layer_1 >> other.get_layer_1();
        m_layer_output >> other.get_layer_output();

        return *this;
    }

    template < class Other >
    CNN2Layer &operator<<( IN Other &other )
    {
        m_layer_0 << other.get_layer_0();
        m_layer_1 << other.get_layer_1();
        m_layer_output << other.get_layer_output();

        return *this;
    }

    void forward(void)
    {
        m_input.forward();

        m_bias_0.forward();
        m_layer_0.forward();

        m_bias_1.forward();
        m_layer_1.forward();

        m_bias_output.forward();
        m_layer_output.forward();
    }

    void backward(void)
    {
        m_layer_output.backward();
        m_layer_1.backward();
        m_layer_0.backward();
    }

    void update(void)
    {
        m_layer_0.update();
        m_layer_1.update();
        m_layer_output.update();
    }

    void set_input( IN const double (&input)[InputNum] )
    {
        m_input.set_input(input);
    }

    void set_target( IN const double (&target)[OutputNum] )
    {
        m_layer_output.set_target(target);
    }

    inline Layer0 &get_layer_0(void)
    {
        return m_layer_0;
    }

    inline Layer1 &get_layer_1(void)
    {
        return m_layer_1;
    }

    inline LayerOutput &get_layer_output(void)
    {
        return m_layer_output;
    }

#ifdef _DEBUG
    void print_weight(void) const
    {
        m_layer_0.print_weight();
        m_layer_1.print_weight();
        m_layer_output.print_weight();
    }
#endif // _DEBUG

private:

    void connect_inner(void)
    {
        double bias[1] = {1.0};

        m_bias_0.set_input(bias);
        m_layer_0.connect_input_layer(m_bias_0);
        m_layer_0.connect_input_layer(m_input);

        m_bias_1.set_input(bias);
        m_layer_1.connect_input_layer(m_bias_1);
        m_layer_1.connect_input_layer(m_layer_0);

        m_bias_output.set_input(bias);
        m_layer_output.connect_input_layer(m_bias_output);
        m_layer_output.connect_input_layer(m_layer_1);
    }

private:

    CLayerInput< InputNum, HiddenNum0 > m_input;

    CLayerInput< 1, HiddenNum0 > m_bias_0;
    Layer0 m_layer_0;

    CLayerInput< 1, HiddenNum1 > m_bias_1;
    Layer1 m_layer_1;

    CLayerInput< 1, OutputNum > m_bias_output;
    LayerOutput m_layer_output;
};

template < uint32 PatternNum,
           uint32 InputNum,
           uint32 HiddenNum0, class Xfer0,
           uint32 HiddenNum1, class Xfer1,
           uint32 OutputNum, class XferOutput,
           class Param >
class CNN2Layer< PatternNum,
                 InputNum,
                 HiddenNum0, Xfer0,
                 HiddenNum1, Xfer1,
                 OutputNum, XferOutput,
                 CWeightLM, Param >
{
private:

    typedef CLayer< PatternNum, InputNum + 1, HiddenNum0, HiddenNum1, Xfer0,
                    CWeightLM, Param > Layer0;
    typedef CLayer< PatternNum, HiddenNum0 + 1, HiddenNum1, OutputNum, Xfer1,
                    CWeightLM, Param > Layer1;
    typedef CLayerOutput< PatternNum, HiddenNum1 + 1, OutputNum, XferOutput,
                          CWeightLM, Param > LayerOutput;

public:

    CNN2Layer(void)
        : m_check(false)
        , m_se_prev(0.0)
        , m_se(0.0)
        , m_pattern_idx(0)
    {
        connect_inner();
    }

    ~CNN2Layer(void)
    {
    }

    template < class Other >
    const CNN2Layer &operator>>( OUT Other &other ) const
    {
        return *this;
    }

    template < class Other >
    CNN2Layer &operator<<( IN Other &other )
    {
        return *this;
    }

    void forward(void)
    {
        m_input.forward();

        m_bias_0.forward();
        m_layer_0.forward();

        m_bias_1.forward();
        m_layer_1.forward();

        m_bias_output.forward();
        m_layer_output.forward();
    }

    void backward(void)
    {
        if (m_check)
        {
            for ( uint32 i = 0; i < OutputNum; ++i )
            {
                m_se += pow( m_layer_output.get_error(i), 2 );
            }
        }
        else
        {
            for ( uint32 i = 0; i < OutputNum; ++i )
            {
                m_err[ m_pattern_idx * OutputNum + i ] = m_layer_output.get_error(i);

                m_layer_output.backward( m_pattern_idx, i );
                m_layer_1.backward( m_pattern_idx, i );
                m_layer_0.backward( m_pattern_idx, i );

                m_se_prev += pow( m_err[ m_pattern_idx * OutputNum + i ], 2 );
            }

            ++m_pattern_idx;
        }
    }

    void update(void)
    {
        if (m_check)
        {
            if ( m_se < m_se_prev )
            {
                Param::lambda /= Param::beta;
                if ( Param::lambda < DOUBLE_EPSILON )
                {
                    Param::lambda = DOUBLE_EPSILON;
                }
            }
            else
            {
                revert();

                Param::lambda *= Param::beta;
                if ( Param::lambda > DOUBLE_MAX )
                {
                    Param::lambda = DOUBLE_MAX;
                }
            }

            m_se_prev = 0.0;
            m_check = false;
        }
        else
        {
            m_layer_0.update(m_err);
            m_layer_1.update(m_err);
            m_layer_output.update(m_err);

            m_check = true;
            m_se = 0.0;
            m_pattern_idx = 0;
        }
    }

    void set_input( IN const double (&input)[InputNum] )
    {
        m_input.set_input(input);
    }

    void set_target( IN const double (&target)[OutputNum] )
    {
        m_layer_output.set_target(target);
    }

    inline Layer0 &get_layer_0(void)
    {
        return m_layer_0;
    }

    inline Layer1 &get_layer_1(void)
    {
        return m_layer_1;
    }

    inline LayerOutput &get_layer_output(void)
    {
        return m_layer_output;
    }

#ifdef _DEBUG
    void print_weight(void) const
    {
        m_layer_0.print_weight();
        m_layer_1.print_weight();
        m_layer_output.print_weight();
    }
#endif // _DEBUG

private:

    void revert(void)
    {
        m_layer_0.revert();
        m_layer_1.revert();
        m_layer_output.revert();
    }

    void connect_inner(void)
    {
        double bias[1] = {1.0};

        m_bias_0.set_input(bias);
        m_layer_0.connect_input_layer(m_bias_0);
        m_layer_0.connect_input_layer(m_input);

        m_bias_1.set_input(bias);
        m_layer_1.connect_input_layer(m_bias_1);
        m_layer_1.connect_input_layer(m_layer_0);

        m_bias_output.set_input(bias);
        m_layer_output.connect_input_layer(m_bias_output);
        m_layer_output.connect_input_layer(m_layer_1);
    }

private:

    CLayerInput< InputNum, HiddenNum0 > m_input;

    CLayerInput< 1, HiddenNum0 > m_bias_0;
    Layer0 m_layer_0;

    CLayerInput< 1, HiddenNum1 > m_bias_1;
    Layer1 m_layer_1;

    CLayerInput< 1, OutputNum > m_bias_output;
    LayerOutput m_layer_output;

    bool m_check;
    double m_se_prev;
    double m_se;
    double m_err[ PatternNum * OutputNum ];
    uint32 m_pattern_idx;
};

} // namespace wwd

#endif // NN_2_LAYER_HPP

