#ifndef XFER_ITF_HPP_
#define XFER_ITF_HPP_

#include "../utility/type.hpp"

namespace wwd
{

class IXfer
{
protected:

    IXfer(void)
    {
    }

    ~IXfer(void)
    {
    }
};

}

#endif // XFER_ITF_HPP_

