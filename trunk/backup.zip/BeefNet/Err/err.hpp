#ifndef ERR_HPP_
#define ERR_HPP_

#include "err_mae.hpp"
#include "err_mse.hpp"
#include "err_rmse.hpp"

#endif // ERR_HPP_

