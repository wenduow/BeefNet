#ifndef ERR_ITF_HPP_
#define ERR_ITF_HPP_

#include <cmath>
#include "../utility/type.hpp"

namespace wwd
{

class IErr
{
protected:

    IErr(void)
    {
    }

    ~IErr(void)
    {
    }
};

} // namespace wwd

#endif // ERR_ITF_HPP_

