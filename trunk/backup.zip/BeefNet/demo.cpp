#include "NN/Net/nn_2_layer.hpp"
#include "NN/Weight/weight_lm.hpp"
#include "NN/Weight/param_lm.hpp"
#include "Xfer/xfer_lnr.hpp"

using namespace wwd;

int32 main(void)
{
    typedef CNN2Layer< 100,
                       2,
                       2, FXferLnr,
                       2, FXferLnr,
                       2, FXferLnr,
                       CWeightLM, EParamLM<2> > NN;

    NN nn, nn_image;

    for ( uint32 i = 0; i < 2000; ++i )
    {
        nn >> nn_image;

        for ( uint32 j = 1; j <= 100; ++j )
        {
            double input[2] = { 0.01 * j / 4.0, 0.02 * j / 4.0 };
            double target[2] = { 0.03 * j / 4.0, 0.04 * j / 4.0 };

            nn.set_input(input);
            nn.set_target(target);

            nn.forward();
            nn.backward();
        }

        nn << nn_image;

        nn.update();
    }

#ifdef _DEBUG
    nn.print_weight();
#endif // _DEBUG

    return 0;
}

